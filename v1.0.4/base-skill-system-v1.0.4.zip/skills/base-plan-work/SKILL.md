---
name: base-plan-work
description: Generar un plan de trabajo por fases con archivos a tocar, cambios de codigo esperados, justificacion y estado. Usar cuando el usuario pida planificar una tarea antes de implementarla.
---

# Base Plan Work

## Proposito
Planificar trabajo de forma ejecutable y documentable, sin depender de lenguaje o framework.

## Salida minima obligatoria
1. Descripcion general del desarrollo.
2. Fases logicas.
3. Archivos o rutas a tocar por fase.
4. Modificaciones de codigo esperadas por fase.
5. Justificacion tecnica o funcional de cada cambio.
6. Fecha de solicitud.
7. Estado del plan.

## Estado permitido
- Planificado
- En desarrollo
- Completado

## Skills relacionadas
- Llamadas obligatorias:
  - `base-project-bootstrap`
  - `base-golden-rules`
  - `base-document-project`
  - `base-memory-protocol` cuando la memoria afecte la secuencia del plan
- Llamadas opcionales:
  - `base-analyze-module`
  - `base-test-strategy`

## Flujo
1. Ejecutar `base-project-bootstrap`.
2. Consultar `Memory/PlanningMemory.md` si existe para reutilizar fases o secuencias ya probadas.
3. Si hace falta mas memoria que la de planificacion, aplicar `base-memory-protocol` y consultar solo la memoria estrictamente relevante.
4. Confirmar objetivo y alcance.
5. Dividir en fases logicas.
6. Para cada fase, detallar:
- objetivo
- archivos/rutas a tocar
- cambios esperados
- motivo del cambio
7. Añadir riesgos y dependencias solo si cambian la ejecucion.
8. Guardar con `base-document-project` en `PLANES/AAAA_MM_DD_slug.md`.
9. Si una estructura de fases demuestra valor recurrente, promoverla a `Memory/PlanningMemory.md`.

## Reglas
- No crear fases artificiales para rellenar.
- Cada fase debe ser implementable y verificable.
- Si no es posible identificar archivos exactos, indicar rutas candidatas y decir que requieren confirmacion o investigacion.
- No promocionar a memoria planes puntuales que no generalicen a futuras tareas del mismo contexto.
- No consultar memoria adicional si no cambia el plan de forma real.
